import{R as t}from"./control.f5b05b5f.js";function o(e,r){return new t(e,r)}new TextEncoder;export{o as r};
//# sourceMappingURL=index.ade5cbd2.js.map
